Exercise 2.2
1.Write a Scilab program to compute sum of first ‘n’ natural numbers.

n=10
    if n <= 0 then
        error("Input must be a positive integer.");
    end
    sum = n * (n + 1) / 2;
    disp("The sum of the first " + string(n) + " natural numbers is: " + string(sum));
  

op////////////////

--> 

--> n=10
 n  = 

   10.

-->     if n <= 0 then
  >         error("Input must be a positive integer.");
  >     end

-->     sum = n * (n + 1) / 2;

-->     disp("The sum of the first " + string(n) + " natural numbers is: " + string(sum));

  "The sum of the first 10 natural numbers is: 55"

-->   

------------------------------------------------------------------------------------------------------------

2. Write a Scilab program to compute factorial of a natural number ‘n’.


n=5
    if n < 0 then
        error("Input must be a non-negative integer.");
    end
    factorial = 1;
    for i = 1:n
        factorial = factorial * i;
    end
    disp("The factorial of " + string(n) + " is: " + string(factorial));
  


op///////////////////////////////////////////////////////////////////

-
--> n=5
 n  = 

   5.

-->     if n < 0 then
  >         error("Input must be a non-negative integer.");
  >     end

-->     factorial = 1;

-->     for i = 1:n
  >         factorial = factorial * i;
  >     end

-->     disp("The factorial of " + string(n) + " is: " + string(factorial));

  "The factorial of 5 is: 120"

-->   


------------------------------------------------------------------------------------------------------------

3.Write a Scilab program to obtain the Fibonacci sequence with ‘n’
members, and Fibonacci series with ‘n’ terms.


n=10
    if n <= 0 then
        error("Input must be a positive integer.");
    end
    fib_seq = zeros(1, n);
    fib_seq(1) = 0;
    if n > 1 then
        fib_seq(2) = 1;
    end
    for i = 3:n
        fib_seq(i) = fib_seq(i - 1) + fib_seq(i - 2);
    end
    disp("The Fibonacci sequence with " + string(n) + " members is: " );
    disp(string(fib_seq))
 

op/////////////////////////////////////////////////////////////////////
-> n=10
 n  = 

   10.

-->     if n <= 0 then
  >         error("Input must be a positive integer.");
  >     end

-->     fib_seq = zeros(1, n);

-->     fib_seq(1) = 0;

-->     if n > 1 then
  >         fib_seq(2) = 1;
  >     end

-->     for i = 3:n
  >         fib_seq(i) = fib_seq(i - 1) + fib_seq(i - 2);
  >     end

-->     disp("The Fibonacci sequence with " + string(n) + " members is: " );

  "The Fibonacci sequence with 10 members is: "

-->     disp(string(fib_seq))

  "0"  "1"  "1"  "2"  "3"  "5"  "8"  "13"  "21"  "34"

-->  

------------------------------------------------------------------------------------------------------------

4.Write a Scilab program to test whether a given number is prime number or
not.

n=29
    if n <= 1 then
        disp(string(n) + " is not a prime number.");
        return;
    end
    is_prime = %t;
    for i = 2:sqrt(n)
        if (modulo(n , i) == 0) then
            is_prime = %f;
            break;
        end
    end
    if is_prime then
        disp(string(n) + " is a prime number.");
    else
        disp(string(n) + " is not a prime number.");
    end
 

op///////////////////////

--> 

--> n=29
 n  = 

   29.

-->     if n <= 1 then
  >         disp(string(n) + " is not a prime number.");
  >         return;
  >     end

-->     is_prime = %t;

-->     for i = 2:sqrt(n)
  >         if (modulo(n , i) == 0) then
  >             is_prime = %f;
  >             break;
  >         end
  >     end

-->     if is_prime then
  >         disp(string(n) + " is a prime number.");
  >     else
  >         disp(string(n) + " is not a prime number.");
  >     end

  "29 is a prime number."

-->  


------------------------------------------------------------------------------------------------------------
5.Write a Scilab program using for loop to compute the sum of two given
matrices, if they are of comparable order.

A = [1 2 3; 4 5 6; 7 8 9];
B = [10 11 12; 13 14 15; 16 17 18];
[m, n] = size(A);
[p, q] = size(B);
if m ~= p | n ~= q then
    error("Matrices are not of comparable order.");
end
C = zeros(m, n);
for i = 1:m
    for j = 1:n
        C(i, j) = A(i, j) + B(i, j);
    end
end
disp("Sum of the matrices:");
disp(C);


op/////////////////////////////////////


--> 

--> A = [1 2 3; 4 5 6; 7 8 9];

--> B = [10 11 12; 13 14 15; 16 17 18];

--> [m, n] = size(A);

--> [p, q] = size(B);

--> if m ~= p | n ~= q then
  >     error("Matrices are not of comparable order.");
  > end

--> C = zeros(m, n);

--> for i = 1:m
  >     for j = 1:n
  >         C(i, j) = A(i, j) + B(i, j);
  >     end
  > end

--> disp("Sum of the matrices:");

  "Sum of the matrices:"

--> disp(C);

   11.   13.   15.
   17.   19.   21.
   23.   25.   27.


------------------------------------------------------------------------------------------------------------
6.Write a Scilab program using for loop to compute the matrix multiplication
of two given matrices, if they are of comparable order. Verify the
obtained matrix by using Scilab matrix multiplication operator ‘*’.


A = [1, 2; 3, 4];
B = [5, 6; 7, 8];
   [m1, n1] = size(A);
    [m2, n2] = size(B);
    if n1 ~= m2 then
        error("Number of columns of A must be equal to number of rows of B.");
    end
    C = zeros(m1, n2);
    for i = 1:m1
        for j = 1:n2
            for k = 1:n1
                C(i, j) = C(i, j) + A(i, k) * B(k, j);
            end
        end
    end
    disp("The matrix multiplication result is:");
    disp(C);
    disp("Verification using Scilab matrix multiplication operator *:");
    disp(A * B);



op//////////////////////////////////////////////////////////////////////////////


--> 

--> A = [1, 2; 3, 4];

--> B = [5, 6; 7, 8];

-->    [m1, n1] = size(A);

-->     [m2, n2] = size(B);

-->     if n1 ~= m2 then
  >         error("Number of columns of A must be equal to number of rows of B.");
  >     end

-->     C = zeros(m1, n2);

-->     for i = 1:m1
  >         for j = 1:n2
  >             for k = 1:n1
  >                 C(i, j) = C(i, j) + A(i, k) * B(k, j);
  >             end
  >         end
  >     end

-->     disp("The matrix multiplication result is:");

  "The matrix multiplication result is:"

-->     disp(C);

   19.   22.
   43.   50.

-->     disp("Verification using Scilab matrix multiplication operator *:");

  "Verification using Scilab matrix multiplication operator *:"

-->     disp(A * B);

   19.   22.
   43.   50.

------------------------------------------------------------------------------------------------------------
7.Write a Scilab program to sorting (arrange) a set of numbers in ascending
and descending order.

numbers = [5, 2, 9, 1, 7];
    sorted_asc = gsort(numbers, 'g', 'i');
    sorted_desc = gsort(numbers, 'g', 'd');
    disp("Numbers in ascending order:");
    disp(sorted_asc);
    disp("Numbers in descending order:");
    disp(sorted_desc);



op////////////////////////////////////////////////////////////////


--> 

--> numbers = [5, 2, 9, 1, 7];

-->     sorted_asc = gsort(numbers, 'g', 'i');

-->     sorted_desc = gsort(numbers, 'g', 'd');

-->     disp("Numbers in ascending order:");

  "Numbers in ascending order:"

-->     disp(sorted_asc);

   1.   2.   5.   7.   9.

-->     disp("Numbers in descending order:");

  "Numbers in descending order:"

-->     disp(sorted_desc);

   9.   7.   5.   2.   1.


------------------------------------------------------------------------------------------------------------
8. Write a Scilab program to compute the number of permutations & number
of combinations for given values of ‘n’ and ‘r’.

n=5
r=3
    if r > n then
        error("r must be less than or equal to n.");
    end
    permutations = factorial(n) / factorial(n - r);
    combinations = factorial(n) / (factorial(r) * factorial(n - r));
    disp("Number of permutations (P(n, r)) is: " + string(permutations));
    disp("Number of combinations (C(n, r)) is: " + string(combinations));
  

op////////////////////////////////////////

--> n=5
 n  = 

   5.

--> r=3
 r  = 

   3.

-->     if r > n then
  >         error("r must be less than or equal to n.");
  >     end

-->     permutations = factorial(n) / factorial(n - r);

-->     combinations = factorial(n) / (factorial(r) * factorial(n - r));

-->     disp("Number of permutations (P(n, r)) is: " + string(permutations));

  "Number of permutations (P(n, r)) is: 60"

-->     disp("Number of combinations (C(n, r)) is: " + string(combinations));

  "Number of combinations (C(n, r)) is: 10"

-->   