Exercise 2.1
1. Write a Scilab program to test whether a given number divides the other
given number.

a=5
b=6

if (modulo(a,b) == 0)
 disp("a given number divides the other given number.")
else
 disp("a given number does not divides the other given number.")
end


op//////////////////////////////////////////////////////////////////////////////////////////////

------------------------------------------------------------------------------------------------------------
2. Write a Scilab program to test whether a given number is even or odd.

a=5
if (modulo(a,2) == 0)
 disp("a given number is even.")
else
 disp("a given number is odd")
end

op//////////////////////////////////////////////////////////////////////////////////////////////


--> a=5
 a  = 

   5.

--> if (modulo(a,2) == 0)
  >  disp("a given number is even.")
  > else
  >  disp("a given number is odd")
  > end

  "a given number is odd"


------------------------------------------------------------------------------------------------------------
3. Write a Scilab program to test whether a given number is purely real
number or a complex number.

number = 3 + 4*%i;  
if imag(number) == 0 then
    disp("Num is a purely real number.")
else
    disp("Num is a complex number.")
end

op//////////////////////////////////////////////////////////////////////////////////////////////


--> number = 3 + 4*%i;  

--> if imag(number) == 0 then
  >     disp("Num is a purely real number.")
  > else
  >     disp("Num is a complex number.")
  > end

  "Num is a complex number."

------------------------------------------------------------------------------------------------------------
4. Write a Scilab program to test whether a given number is positive,
negative, or zero.


number = -5;  

if number > 0 then
    disp("Num is positive.")
elseif number < 0 then
    disp("Num is negative.")
else
    disp("Num is zero.")
end

op//////////////////////////////////////////////////////////////////////////////////////////////


--> number = -5;  

--> 

--> if number > 0 then
  >     disp("Num is positive.")
  > elseif number < 0 then
  >     disp("Num is negative.")
  > else
  >     disp("Num is zero.")
  > end

  "Num is negative."

------------------------------------------------------------------------------------------------------------
5. Write a Scilab program to test whether a given number is positive,
negative, or zero, using select statement.


n = -5;

if n > 0 then
    str_n = "positive";
elseif n < 0 then
    str_n = "negative";
else
    str_n = "zero";
end

select str_n
    case "positive" then
        disp("Number is positive");
    case "negative" then
        disp("Number is negative");
    case "zero" then
        disp("Number is zero");
end

op//////////////////////////////////////////////////////////////////


--> n = -5;

--> 

--> if n > 0 then
  >     str_n = "positive";
  > elseif n < 0 then
  >     str_n = "negative";
  > else
  >     str_n = "zero";
  > end

--> 

--> select str_n
  >     case "positive" then
  >         disp("Number is positive");
  >     case "negative" then
  >         disp("Number is negative");
  >     case "zero" then
  >         disp("Number is zero");
  > end

  "Number is negative"


------------------------------------------------------------------------------------------------------------
6. Write a Scilab program to solve a Quadratic Equation ax 2 + bx + c = 0.
The input to the function are the values “a, b, c” and the output of the
function should be in the variable names “p, q” appropriately declared.




a = 1;  
b = -3;
c = 2;


D = b^2 - 4*a*c;


p = [];
q = [];


if D > 0 then

    p = (-b + sqrt(D)) / (2*a);
    q = (-b - sqrt(D)) / (2*a);
    disp("The quadratic equation has two distinct real roots:");
    disp("Root 1: " + string(p));
    disp("Root 2: " + string(q));
elseif D == 0 then

    p = -b / (2*a);
    disp("The quadratic equation has one real root:");
    disp("Root: " + string(p));
else
  
    realPart = -b / (2*a);
    imaginaryPart = sqrt(-D) / (2*a);
    p = realPart + imaginaryPart * %i;
    q = realPart - imaginaryPart * %i;
    disp("The quadratic equation has two complex conjugate roots:");
    disp("Root 1: " + string(p));
    disp("Root 2: " + string(q));
end


op/////////////////////////////////////////////////////////////

--> a = 1;  

--> b = -3;

--> c = 2;

--> 

--> 

--> D = b^2 - 4*a*c;

--> 

--> 

--> p = [];

--> q = [];

--> 

--> 

--> if D > 0 then
  > 
  >     p = (-b + sqrt(D)) / (2*a);
  >     q = (-b - sqrt(D)) / (2*a);
  >     disp("The quadratic equation has two distinct real roots:");
  >     disp("Root 1: " + string(p));
  >     disp("Root 2: " + string(q));
  > elseif D == 0 then
  > 
  >     p = -b / (2*a);
  >     disp("The quadratic equation has one real root:");
  >     disp("Root: " + string(p));
  > else
  >   
  >     realPart = -b / (2*a);
  >     imaginaryPart = sqrt(-D) / (2*a);
  >     p = realPart + imaginaryPart * %i;
  >     q = realPart - imaginaryPart * %i;
  >     disp("The quadratic equation has two complex conjugate roots:");
  >     disp("Root 1: " + string(p));
  >     disp("Root 2: " + string(q));
  > end

  "The quadratic equation has two distinct real roots:"

  "Root 1: 2"

  "Root 2: 1"














