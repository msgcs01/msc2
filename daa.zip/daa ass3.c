Exercise 3
1. Write a Scilab program to solve a Quadratic Equation ax 2 + bx + c = 0.
The input to the function are the values “a, b, c” and the output of the
function should be in the variable names “p, q” appropriately declared.

function [p, q] = solveQuadratic(a, b, c)
    if a == 0 then
        error("Coefficient a must not be zero in a quadratic equation.");
    end
    D = b^2 - 4*a*c;
    p = [];
    q = [];
    if D > 0 then
        p = (-b + sqrt(D)) / (2*a);
        q = (-b - sqrt(D)) / (2*a);
        disp("The quadratic equation has two distinct real roots:");
        disp("Root 1: " + string(p));
        disp("Root 2: " + string(q));
    elseif D == 0 then
        p = -b / (2*a);
        q = p; 
        disp("The quadratic equation has one real root:");
        disp("Root: " + string(p));
    else
        realPart = -b / (2*a);
        imaginaryPart = sqrt(-D) / (2*a);
        p = realPart + imaginaryPart * %i;
        q = realPart - imaginaryPart * %i;
        disp("The quadratic equation has two complex conjugate roots:");
        disp("Root 1: " + string(p));
        disp("Root 2: " + string(q));
    end
endfunction
a = 1;
b = -3;
c = 2;
[p, q] = solveQuadratic(a, b, c);


/////////////////////////Op//////////////////////////////////////////////////////////



--> 

--> function [p, q] = solveQuadratic(a, b, c)
  >     if a == 0 then
  >         error("Coefficient a must not be zero in a quadratic equation.");
  >     end
  >     D = b^2 - 4*a*c;
  >     p = [];
  >     q = [];
  >     if D > 0 then
  >         p = (-b + sqrt(D)) / (2*a);
  >         q = (-b - sqrt(D)) / (2*a);
  >         disp("The quadratic equation has two distinct real roots:");
  >         disp("Root 1: " + string(p));
  >         disp("Root 2: " + string(q));
  >     elseif D == 0 then
  >         p = -b / (2*a);
  >         q = p; 
  >         disp("The quadratic equation has one real root:");
  >         disp("Root: " + string(p));
  >     else
  >         realPart = -b / (2*a);
  >         imaginaryPart = sqrt(-D) / (2*a);
  >         p = realPart + imaginaryPart * %i;
  >         q = realPart - imaginaryPart * %i;
  >         disp("The quadratic equation has two complex conjugate roots:");
  >         disp("Root 1: " + string(p));
  >         disp("Root 2: " + string(q));
  >     end
  > endfunction

--> a = 1;

--> b = -3;

--> c = 2;

--> [p, q] = solveQuadratic(a, b, c);

  "The quadratic equation has two distinct real roots:"

  "Root 1: 2"

  "Root 2: 1"


-------------------------------------------------------------------------------------------------

2. Write a Scilab program to compute sum of first ‘n’ natural numbers.
function s = sumOfNaturalNumbers(n)
    if n <= 0 then
        error("Input must be a positive integer.");
    end
    s = n * (n + 1) / 2;
endfunction
n = 10;
sum = sumOfNaturalNumbers(n);
disp("The sum of the first " + string(n) + " natural numbers is: " + string(sum));


/////////////////////////Op//////////////////////////////////////////////////////////
---------------------------------------------------------------------------------
3. Write a Scilab program to compute factorial of a natural number ‘n’.

function f = fact(n)
    if n < 0 then
        error("Input must be a non-negative integer.");
    end
    factorial = 1;
    for i = 1:n
        factorial = factorial * i;
    end
    disp("The factorial of " + string(n) + " is: " + string(factorial));
    f = factorial
endfunction
n=10
factorial1=fact(n);

/////////////////////////Op//////////////////////////////////////////////////////////
--> 

--> function f = fact(n)
  >     if n < 0 then
  >         error("Input must be a non-negative integer.");
  >     end
  >     factorial = 1;
  >     for i = 1:n
  >         factorial = factorial * i;
  >     end
  >     disp("The factorial of " + string(n) + " is: " + string(factorial));
  >     f = factorial
  > endfunction
Warning : redefining function: fact                    . Use funcprot(0) to avoid this message

--> n=10
 n  = 

   10.

--> factorial1=fact(n);

  "The factorial of 10 is: 3628800"

----------------


-------------------------------------------------------------------------------------------------


4. Write a Scilab program using for loop to compute the sum of two given
matrices, if they are of comparable order.

A = [1, 2, 3; 4, 5, 6; 7, 8, 9];
B = [9, 8, 7; 6, 5, 4; 3, 2, 1];
[rowsA, colsA] = size(A);
[rowsB, colsB] = size(B);
if rowsA <> rowsB | colsA <> colsB then
    error("Matrices must be of the same order.");
end

C = zeros(rowsA, colsA);
for i = 1:rowsA
    for j = 1:colsA
        C(i, j) = A(i, j) + B(i, j);
    end
end
disp("The sum of the matrices is:");
disp(C);

/////////////////////////Op//////////////////////////////////////////////////////////


--> A = [1, 2, 3; 4, 5, 6; 7, 8, 9];

--> B = [9, 8, 7; 6, 5, 4; 3, 2, 1];

--> [rowsA, colsA] = size(A);

--> [rowsB, colsB] = size(B);

--> if rowsA <> rowsB | colsA <> colsB then
  >     error("Matrices must be of the same order.");
  > end

--> 

--> C = zeros(rowsA, colsA);

--> for i = 1:rowsA
  >     for j = 1:colsA
  >         C(i, j) = A(i, j) + B(i, j);
  >     end
  > end

--> disp("The sum of the matrices is:");

  "The sum of the matrices is:"

--> disp(C);

   10.   10.   10.
   10.   10.   10.
   10.   10.   10.


-------------------------------------------------------------------------------------------------


5. Write a Scilab program to compute the number of permutations &
number of combinations for given values of ‘n’ and ‘r’.

function p = permutations(n, r)
    p = factorial(n) / factorial(n - r);
endfunction

function c = combinations(n, r)
    c = factorial(n) / (factorial(r) * factorial(n - r));
endfunction

n = 5;
r = 3;

if r > n then
    error("r must be less than or equal to n.");
end

perm = permutations(n, r);
comb = combinations(n, r);

disp("Number of permutations (P(n, r)) is: " + string(perm));
disp("Number of combinations (C(n, r)) is: " + string(comb));


/////////////////////////Op//////////////////////////////////////////////////////////


--> 

--> function p = permutations(n, r)
  >     p = factorial(n) / factorial(n - r);
  > endfunction
Warning : redefining function: permutations            . Use funcprot(0) to avoid this message

--> 

--> function c = combinations(n, r)
  >     c = factorial(n) / (factorial(r) * factorial(n - r));
  > endfunction
Warning : redefining function: combinations            . Use funcprot(0) to avoid this message

--> 

--> n = 5;

--> r = 3;

--> 

--> if r > n then
  >     error("r must be less than or equal to n.");
  > end

--> 

--> perm = permutations(n, r);

--> comb = combinations(n, r);

--> 

--> disp("Number of permutations (P(n, r)) is: " + string(perm));

  "Number of permutations (P(n, r)) is: 60"

--> disp("Number of combinations (C(n, r)) is: " + string(comb));

  "Number of combinations (C(n, r)) is: 10"


-------------------------------------------------------------------------------------------------


6. Write a Scilab program to compute sum of digits of a natural number ‘n’.

function digit_sum = sum_of_digits(n)
    digit_sum = 0;
    while n > 0
        digit_sum = digit_sum + modulo(n, 10);
        n = floor(n / 10);
    end
endfunction

n = 12345;
result = sum_of_digits(n);
disp("The sum of the digits is: " + string(result));

/////////////////////////Op//////////////////////////////////////////////////////////


--> function digit_sum = sum_of_digits(n)
  >     digit_sum = 0;
  >     while n > 0
  >         digit_sum = digit_sum + modulo(n, 10);
  >         n = floor(n / 10);
  >     end
  > endfunction
Warning : redefining function: sum_of_digits           . Use funcprot(0) to avoid this message

--> 

--> n = 12345;

--> result = sum_of_digits(n);

--> disp("The sum of the digits is: " + string(result));

  "The sum of the digits is: 15"


-------------------------------------------------------------------------------------------------


7. Write a Scilab program to find the number of digits of a natural number
‘n’.

function num_digits = count_digits(n)
    num_digits = 0;
    while n > 0
        num_digits = num_digits + 1;
        n = floor(n / 10);
    end
endfunction

n = 12345;
result = count_digits(n);
disp("The number of digits is: " + string(result));

/////////////////////////Op//////////////////////////////////////////////////////////

--> function num_digits = count_digits(n)
  >     num_digits = 0;
  >     while n > 0
  >         num_digits = num_digits + 1;
  >         n = floor(n / 10);
  >     end
  > endfunction

--> 

--> n = 12345;

--> result = count_digits(n);

--> disp("The number of digits is: " + string(result));

  "The number of digits is: 5"



-------------------------------------------------------------------------------------------------


8. Write a Scilab program to obtain a number with digits as the reverse of a
given natural number ‘n’.

function reversed_number = reverse_digits(n)
    reversed_number = 0;
    while n > 0
        reversed_number = reversed_number * 10 + modulo(n, 10);
        n = floor(n / 10);
    end
endfunction

n = 12345;
result = reverse_digits(n);
disp("The number with digits reversed is: " + string(result));

/////////////////////////Op//////////////////////////////////////////////////////////


--> function reversed_number = reverse_digits(n)
  >     reversed_number = 0;
  >     while n > 0
  >         reversed_number = reversed_number * 10 + modulo(n, 10);
  >         n = floor(n / 10);
  >     end
  > endfunction

--> 

--> n = 12345;

--> result = reverse_digits(n);

--> disp("The number with digits reversed is: " + string(result));

  "The number with digits reversed is: 54321"


-------------------------------------------------------------------------------------------------


9. Write a Scilab program to test whether a given number is Palindrome.

function is_palindrome = check_palindrome(n)
    original_number = n;
    reversed_number = 0;
    while n > 0
        reversed_number = reversed_number * 10 + modulo(n, 10);
        n = floor(n / 10);
    end
    is_palindrome = (reversed_number == original_number);
endfunction
n = 12321;
result = check_palindrome(n);
if result then
    disp("The number " + string(n) + " is a palindrome.");
else
    disp("The number " + string(n) + " is not a palindrome.");
end


/////////////////////////Op//////////////////////////////////////////////////////////

--> function is_palindrome = check_palindrome(n)
  >     original_number = n;
  >     reversed_number = 0;
  >     while n > 0
  >         reversed_number = reversed_number * 10 + modulo(n, 10);
  >         n = floor(n / 10);
  >     end
  >     is_palindrome = (reversed_number == original_number);
  > endfunction
Warning : redefining function: check_palindrome        . Use funcprot(0) to avoid this message

--> n = 12321;

--> result = check_palindrome(n);

--> if result then
  >     disp("The number " + string(n) + " is a palindrome.");
  > else
  >     disp("The number " + string(n) + " is not a palindrome.");
  > end

  "The number 12321 is a palindrome."


-------------------------------------------------------------------------------------------------


10. Write a Scilab program to test whether a given number is Armstrong
number.

function is_armstrong = check_armstrong(n)
    num_digits = 0;
    sum_of_powers = 0;
    original_number = n;
    
    temp = n;
    while temp > 0
        num_digits = num_digits + 1;
        temp = floor(temp / 10);
    end

    temp = n;
    while temp > 0
        digit = modulo(temp, 10);
        sum_of_powers = sum_of_powers + digit^num_digits;
        temp = floor(temp / 10);
    end
    
    is_armstrong = (sum_of_powers == original_number);
endfunction

n = 153;
result = check_armstrong(n);
if result then
    disp("The number " + string(n) + " is an Armstrong number.");
else
    disp("The number " + string(n) + " is not an Armstrong number.");
end

/////////////////////////Op//////////////////////////////////////////////////////////


--> function is_armstrong = check_armstrong(n)
  >     num_digits = 0;
  >     sum_of_powers = 0;
  >     original_number = n;
  >     
  >     temp = n;
  >     while temp > 0
  >         num_digits = num_digits + 1;
  >         temp = floor(temp / 10);
  >     end
  > 
  >     temp = n;
  >     while temp > 0
  >         digit = modulo(temp, 10);
  >         sum_of_powers = sum_of_powers + digit^num_digits;
  >         temp = floor(temp / 10);
  >     end
  >     
  >     is_armstrong = (sum_of_powers == original_number);
  > endfunction

--> 

--> n = 153;

--> result = check_armstrong(n);

--> if result then
  >     disp("The number " + string(n) + " is an Armstrong number.");
  > else
  >     disp("The number " + string(n) + " is not an Armstrong number.");
  > end

  "The number 153 is an Armstrong number."


-------------------------------------------------------------------------------------------------


11. Write a Scilab program to obtain the binary equivalent of a given
decimal number.

function binary_str = decimal_to_binary(n)
    binary_str = "";
    if n == 0 then
        binary_str = "0";
        return;
    end

    while n > 0
        binary_str = string(modulo(n, 2)) + binary_str;
        n = floor(n / 2);
    end
endfunction

n = 29;
binary_representation = decimal_to_binary(n);
disp("The binary equivalent of the decimal number " + string(n) + " is: " + binary_representation);

/////////////////////////Op//////////////////////////////////////////////////////////


--> function binary_str = decimal_to_binary(n)
  >     binary_str = "";
  >     if n == 0 then
  >         binary_str = "0";
  >         return;
  >     end
  > 
  >     while n > 0
  >         binary_str = string(modulo(n, 2)) + binary_str;
  >         n = floor(n / 2);
  >     end
  > endfunction

--> 

--> n = 29;

--> binary_representation = decimal_to_binary(n);

--> disp("The binary equivalent of the decimal number " + string(n) + " is: " + binary_representation);

  "The binary equivalent of the decimal number 29 is: 11101"


-------------------------------------------------------------------------------------------------


12. Write a Scilab program to obtain the decimal equivalent of a given
binary number.

binary_str = "1101";
decimal_equivalent = bin2dec(binary_str);
disp("The decimal equivalent of the binary number " + binary_str + " is: " + string(decimal_equivalent));

/////////////////////////Op//////////////////////////////////////////////////////////



--> binary_str = "1101";

--> decimal_equivalent = bin2dec(binary_str);

--> disp("The decimal equivalent of the binary number " + binary_str + " is: " + string(decimal_equivalent));

  "The decimal equivalent of the binary number 1101 is: 13"

-------------------------------------------------------------------------------------------------




1. write a scilab program to sort 10 no. using bubble sort in increasing order.
function A = bubble_sort(A)
    n = length(A);
    for i = 1:n-1
        for j = 1:n-i
            if A(j) > A(j+1) then
                temp = A(j);
                A(j) = A(j+1);
                A(j+1) = temp;
            end
        end
    end
endfunction

A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];
A = bubble_sort(A);
disp(A);

///////////////////////////////////////////////////op//////////////////


--> function A = bubble_sort(A)
  >     n = length(A);
  >     for i = 1:n-1
  >         for j = 1:n-i
  >             if A(j) > A(j+1) then
  >                 temp = A(j);
  >                 A(j) = A(j+1);
  >                 A(j+1) = temp;
  >             end
  >         end
  >     end
  > endfunction

--> 

--> A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];

--> A = bubble_sort(A);

--> disp(A);

   1.   2.   3.   4.   5.   6.   7.   8.   9.   10.

-------------------------------------------------------------------------
2. write a scilab program to sort 10 no. using insesrtion sort in increasing order.

function A = insertion_sort(A)
    n = length(A);
    for i = 2:n
        key = A(i);
        j = i - 1;
        while j >= 1 & A(j) > key
            A(j+1) = A(j);
            j = j - 1;
        end
        A(j+1) = key;
    end
endfunction

A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];
A = insertion_sort(A);
disp(A);

///////////////////////////////////////////////////op//////////////////


--> function A = insertion_sort(A)
  >     n = length(A);
  >     for i = 2:n
  >         key = A(i);
  >         j = i - 1;
  >         while j >= 1 & A(j) > key
  >             A(j+1) = A(j);
  >             j = j - 1;
  >         end
  >         A(j+1) = key;
  >     end
  > endfunction

--> 

--> A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];

--> A = insertion_sort(A);

--> disp(A);

   1.   2.   3.   4.   5.   6.   7.   8.   9.   10.

-------------------------------------------------------------------------

3. write a scilab program to find a no. using linear search.
function index = linear_search(A, target)
    index = -1;
    for i = 1:length(A)
        if A(i) == target then
            index = i;
            break;
        end
    end
endfunction

A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];
target = 5;
index = linear_search(A, target);
disp(index);


///////////////////////////////////////////////////op//////////////////


--> function index = linear_search(A, target)
  >     index = -1;
  >     for i = 1:length(A)
  >         if A(i) == target then
  >             index = i;
  >             break;
  >         end
  >     end
  > endfunction

--> 

--> A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];

--> target = 5;

--> index = linear_search(A, target);

--> disp(index);

   6.

-------------------------------------------------------------------------

4. Accept 5 no. from user and accept no. to search in that array.
function index = linear_search(A, target)
    index = -1;
    for i = 1:length(A)
        if A(i) == target then
            index = i;
            break;
        end
    end
endfunction
A = [10, 20, 30, 40, 50];
target = 30;
index = linear_search(A, target);
if index == -1 then
    disp("Number not found.");
else
    disp("Number found at position: " + string(index));
end


///////////////////////////////////////////////////op//////////////////

--> function index = linear_search(A, target)
  >     index = -1;
  >     for i = 1:length(A)
  >         if A(i) == target then
  >             index = i;
  >             break;
  >         end
  >     end
  > endfunction

--> A = [10, 20, 30, 40, 50];

--> target = 30;

--> index = linear_search(A, target);

--> if index == -1 then
  >     disp("Number not found.");
  > else
  >     disp("Number found at position: " + string(index));
  > end

  "Number found at position: 3"


-------------------------------------------------------------------------

