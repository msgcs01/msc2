1. Use assignment operator for creating and setting (assigning)
variables to float value, string, Boolean values,


--> float_v = 3.14;

--> string_v = "Hello, world!";

--> boolean_v= %T;

------------------------------------------------------------------------------------------------------------
2. Use of comment and continuation line,

--> // This is a single-line comment

--> 

--> // Example of a continuation line:

--> result = 3.14 + 2.71 + 1.41 + ...
  >          0.57; // Continues the addition on the next line

------------------------------------------------------------------------------------------------------------
3. Use of inbuilt Mathematical function and operators,
    
    
--> pi_value = %pi;       

--> e_value = %e;        

------------------------------------------------------------------------------------------------------------
4. Use of pre-defined Mathematical variables,


--> x = 5;

--> y = 10;

--> 

--> // Comparison operators

--> is_equal = (x == y);       

--> is_greater = (x > y);     

--> is_less = (x < y);      

--> 
------------------------------------------------------------------------------------------------------------

5. Use of Booleans and comparison operators,

--> // Boolean values

--> true_value = %T;   // True

--> false_value = %F;  // False

--> 
------------------------------------------------------------------------------------------------------------
6. Use of complex numbers, and operations on them,


--> 
--> z1 = 3 + 4*%i;    

--> z2 = 1 - 2*%i;    

--> 

--> // Operations

--> z_sum = z1 + z2;  

--> z_diff = z1 - z2; 

--> z_prod = z1 * z2; 

--> z_div = z1 / z2;  

------------------------------------------------------------------------------------------------------------
7. Use of strings and concatenation operator, and use of
comparison operator ‘==’ for comparison of two strings for
checking their equality.




--> str1 = "Hello, ";

--> str2 = "world!";

--> 

--> // Concatenation

--> greeting = str1 + str2;  

--> disp(greeting)

  "Hello, world!"

--> // Comparison

--> is_equal_strings = (str1 == "Hello, ");  // True

--> disp(is_equal_strings)

  T

--> is_not_equal_strings = (str2 == "World!"); // False
------------------------------------------------------------------------------------------------------------

8. Swap the values assigned to two variables without using third
variable.

-> 

--> a = 10;

--> b = 20;

--> 

--> a = a + b;  

--> b = a - b; 

--> a = a - b;  

--> 

--> disp(a)

   20.

--> disp(b)

   10.



