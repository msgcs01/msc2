Exercise 4

1. write a scilab program to sort 10 no. using bubble sort in increasing order.
function A = bubble_sort(A)
    n = length(A);
    for i = 1:n-1
        for j = 1:n-i
            if A(j) > A(j+1) then
                temp = A(j);
                A(j) = A(j+1);
                A(j+1) = temp;
            end
        end
    end
endfunction

A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];
A = bubble_sort(A);
disp(A);

///////////////////////////////////////////////////op//////////////////


--> function A = bubble_sort(A)
  >     n = length(A);
  >     for i = 1:n-1
  >         for j = 1:n-i
  >             if A(j) > A(j+1) then
  >                 temp = A(j);
  >                 A(j) = A(j+1);
  >                 A(j+1) = temp;
  >             end
  >         end
  >     end
  > endfunction

--> 

--> A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];

--> A = bubble_sort(A);

--> disp(A);

   1.   2.   3.   4.   5.   6.   7.   8.   9.   10.

-------------------------------------------------------------------------
2. write a scilab program to sort 10 no. using insesrtion sort in increasing order.

function A = insertion_sort(A)
    n = length(A);
    for i = 2:n
        key = A(i);
        j = i - 1;
        while j >= 1 & A(j) > key
            A(j+1) = A(j);
            j = j - 1;
        end
        A(j+1) = key;
    end
endfunction

A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];
A = insertion_sort(A);
disp(A);

///////////////////////////////////////////////////op//////////////////


--> function A = insertion_sort(A)
  >     n = length(A);
  >     for i = 2:n
  >         key = A(i);
  >         j = i - 1;
  >         while j >= 1 & A(j) > key
  >             A(j+1) = A(j);
  >             j = j - 1;
  >         end
  >         A(j+1) = key;
  >     end
  > endfunction

--> 

--> A = [10, 3, 7, 1, 9, 5, 8, 6, 4, 2];

--> A = insertion_sort(A);

--> disp(A);

   1.   2.   3.   4.   5.   6.   7.   8.   9.   10.

-------------------------------------------------------------------------

3. Write a Scilab program to find a number using Linear search. Accept 5
numbers fromthe user and number to find.

function indices = find_all_occurrences(A, target)
    indices = []; 
    for i = 1:length(A)
        if A(i) == target then
            indices = [indices, i]; // Append the index to the list
        end
    end
endfunction

disp("Please enter 5 numbers:");
A = zeros(1, 5); 
for i = 1:5
    A(i) = input("Enter number " + string(i) + ": "); 
end
target = input("Enter the number to find: ");
indices = find_all_occurrences(A, target);
if length(indices) == 0 then
    disp("Number not found in the array.");
else
    disp("Number found at positions: " );
    disp(string(indices));
end

///////////////////////////////////////////////////op//////////////////


--> exec('/opt/scilab-6.1.1/25/new.sce', -1)
Warning : redefining function: find_all_occurrences    . Use funcprot(0) to avoid this message

  "Please enter 5 numbers:"
Enter number 1: 1

Enter number 2: 2

Enter number 3: 1

Enter number 4: 3

Enter number 5: 1

Enter the number to find: 1


  "Number found at positions: 1"  "Number found at positions: 3"  "Number found at positions: 5"

  "1"  "3"  "5"


-------------------------------------------------------------------------
4. Write a Scilab program to find a number using Binary search. Accept 5
numbers fromthe user and number to find.

function indices = find_all_occurrences(A, target)
    indices = [];
    low = 1; // Initial lower bound
    high = length(A); // Initial upper bound
   
    // Perform binary search to find one occurrence
    while low <= high do
        mid = floor((low + high) / 2);
        if A(mid) == target then
            // Once found, find all occurrences
            left = mid;
            right = mid;          
            while left > 1 & A(left-1) == target do
                left = left - 1;
            end
            while right < length(A) & A(right+1) == target do
                right = right + 1;
            end
            indices = left:right;
            return;
        elseif A(mid) < target then
            low = mid + 1; // Search in the right half
        else
            high = mid - 1; // Search in the left half
        end
    end
endfunction

disp("Please enter 5 numbers:");

A = zeros(1, 5);
for i = 1:5
    A(i) = input("Enter number " + string(i) + ": "); // Accept user input
end

//ascending order
A = gsort(A, "g");
target = input("Enter the number to find: ");
indices = find_all_occurrences(A, target);
if length(indices) == 0 then
    disp("Number not found in the array.");
else
    disp("Number found at positions: "  );
    disp(string(indices));
end


///////////////////////////////////////////////////op//////////////////

-> exec('/opt/scilab-6.1.1/25/new.sce', -1)

  "Please enter 5 numbers:"
Enter number 1: 15

Enter number 2: 6

Enter number 3: 6

Enter number 4: 3

Enter number 5: 1

Enter the number to find: 6


  "Number found at positions: "

  "2"  "3"

-------------------------------------------------------------------------

