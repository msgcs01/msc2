Exercise 2.3
1.
Write a Scilab program to find the number of digits of a natural number
‘n’.

n = 12345;
num_digits = length(msprintf("%d", n));
disp("Number of digits: " + string(num_digits));

op//////////////////////////////////////////////////////////////////////////////////////////////

--> n = 12345;

--> num_digits = length(msprintf("%d", n));

--> disp("Number of digits: " + string(num_digits));

  "Number of digits: 5"

------------------------------------------------------------------------------------------------------------
2. Write a Scilab program to obtain a number with digits as the reverse of a
given natural number ‘n’.

n = 12345;
str_n = string(n);
reversed_str_n = part(str_n, length(str_n):-1:1);
reversed_num = evstr(reversed_str_n);
disp("Reversed number: " + string(reversed_num));

op//////////////////////////////////////////////////////////////////////////////////////////////


--> n = 12345;

--> str_n = string(n);

--> reversed_str_n = part(str_n, length(str_n):-1:1);

--> reversed_num = evstr(reversed_str_n);

--> disp("Reversed number: " + string(reversed_num));

  "Reversed number: 54321"

------------------------------------------------------------------------------------------------------------

3. Write a Scilab program to test whether a given number is Palindrome.

n = 12321;
str_n = msprintf("%d", n);
if str_n == strrev(str_n) then
    disp("The number is a palindrome.");
else
    disp("The number is not a palindrome.");
end

op//////////////////////////////////////////////////////////////////////////////////////////////

--> n = 12321;

--> str_n = msprintf("%d", n);

--> if str_n == strrev(str_n) then
  >     disp("The number is a palindrome.");
  > else
  >     disp("The number is not a palindrome.");
  > end

  "The number is a palindrome."

------------------------------------------------------------------------------------------------------------

4. Write a Scilab program to test whether a given number is Armstrong
number.

n = 371;
num_str = msprintf("%d", n);
num_len = length(num_str);
sum = 0;
for i = 1:num_len
    digit = evstr(mid(num_str, i, i));
    sum = sum + digit^num_len;
end
if sum == n then
    disp("The number is an Armstrong number.");
else
    disp("The number is not an Armstrong number.");
end

op//////////////////////////////////////////////////////////////////////////////////////////////

--> n = 371;

--> num_str = msprintf("%d", n);

--> num_len = length(num_str);

--> sum = 0;

--> for i = 1:num_len
  >     digit = evstr(mid(num_str, i, i));
  >     sum = sum + digit^num_len;
  > end

Undefined variable: mid

--> if sum == n then
  >     disp("The number is an Armstrong number.");
  > else
  >     disp("The number is not an Armstrong number.");
  > end

  "The number is not an Armstrong number."

------------------------------------------------------------------------------------------------------------

5.Write a Scilab program to obtain the binary equivalent of a given decimal
number.

dec_num = 10;
bin_str = dec2bin(dec_num);
disp("The binary equivalent is: " + bin_str);



function binaryString = toBinary(n)
    // Handle the special case for zero
    if n == 0 then
        binaryString = "0";
    else
        num = n;
        binaryString = ""; // Initialize an empty string for the binary representation
        // Loop to compute the binary representation
        while num > 0
            remainder = mod(num, 2); // Compute the remainder (0 or 1)
            binaryString = string(remainder) + binaryString; // Append the remainder to the left
            num = floor(num / 2); // Update num for the next iteration
        end
    end
endfunction

decimal_num = input("Enter a decimal number: "); // Prompt for user input

// Call the toBinary function and display the result
binary_rep = toBinary(decimal_num);
disp("The binary equivalent is: " + binary_rep);




function octalString = toOctal(n)
    // Handle the special case for zero
    if n == 0 then
        octalString = "0";
    else
        num = n;
        octalString = ""; // Initialize an empty string for the octal representation
        // Loop to compute the octal representation
        while num > 0
            remainder = mod(num, 8); // Compute the remainder
            octalString = string(remainder) + octalString; // Append the remainder to the left
            num = floor(num / 8); // Update num for the next iteration
        end
    end
endfunction


op//////////////////////////////////////////////////////////////////////////////////////////////


--> dec_num = 10;

--> bin_str = dec2bin(dec_num);

--> disp("The binary equivalent is: " + bin_str);

  "The binary equivalent is: 1010"

------------------------------------------------------------------------------------------------------------

6. Write a Scilab program to obtain the decimal equivalent of a given binary
number.

bin_str = "1010";
dec_num = bin2dec(bin_str);
disp("The decimal equivalent is: " + string(dec_num));




// Function to convert binary to decimal
function decimalValue = bin2dec(binaryString)
    decimalValue = 0; // Initialize the decimal value
    length_bin = length(binaryString); // Length of the binary string
    power = 0; // Initialize power for 2

    // Loop to process the binary string from right to left
    for i = length_bin:-1:1
        digit = ascii(binaryString(i)) - ascii('0'); // Convert character to number (0 or 1)
        decimalValue = decimalValue + digit * 2^power; // Add the contribution to decimal value
        power = power + 1; // Increment the power of 2
    end
endfunction

// Request user input
binary_input = input("Enter a binary number (as a string): ", "string"); // Prompt for user input

// Call the bin2dec function and display the result
decimal_result = bin2dec(binary_input);
disp("The decimal equivalent is: " + string(decimal_result));

op//////////////////////////////////////////////////////////////////////////////////////////////

--> bin_str = "1010";

--> dec_num = bin2dec(bin_str);

--> disp("The decimal equivalent is: " + string(dec_num));

  "The decimal equivalent is: 10"

------------------------------------------------------------------------------------------------------------

7. Write a Scilab program to compute sum of first ‘n’ prime numbers.

n = 10; // change this to compute the sum of the first 'n' prime numbers
sum = 0;
count = 0;
num = 2;
while count < n
    is_prime = %t;
    for i = 2 : sqrt(num)
        if modulo(num, i) == 0 then
            is_prime = %f;
            break;
        end
    end
    if is_prime then
        sum = sum + num;
        count = count + 1;
    end
    num = num + 1;
end
disp("The sum of the first " + string(n) + " prime numbers is: " + string(sum));

//////////////////////////////////////////////////////////////////////////////////////////////


--> n = 10; // change this to compute the sum of the first 'n' prime numbers

--> sum = 0;

--> count = 0;

--> num = 2;

--> while count < n
  >     is_prime = %t;
  >     for i = 2 : sqrt(num)
  >         if modulo(num, i) == 0 then
  >             is_prime = %f;
  >             break;
  >         end
  >     end
  >     if is_prime then
  >         sum = sum + num;
  >         count = count + 1;
  >     end
  >     num = num + 1;
  > end

--> disp("The sum of the first " + string(n) + " prime numbers is: " + string(sum));

  "The sum of the first 10 prime numbers is: 129"


