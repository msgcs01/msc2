1. Write a Scilab program to sort 5 numbers using Merge sort in increasing order.

function mergedArray = mergeSort(left,right)
    mergedArray =[];
    while length(left)>0 && length (right)>0

        if left(1)<right(1)
            mergedArray=[mergedArray,left(1)];
            left=left(2:$);
        else
            mergedArray=[mergedArray,right(1)];
            right=right(2:$);
        end
    end
    mergedArray=[mergedArray,left,right];
endfunction
function sortedArray = mergedArray(arr)
    if length(arr) <= 1 
        sortedArray =arr;
    else
        middle = floor(length(arr)/2);
        left = arr(1:middle);
        right =arr(middle+1 : $);

        sortedArray = mergeSort(mergedArray(left),mergedArray(right));
    end
endfunction
arr= [5,2,1,4,3];
sortedArray= mergedArray(arr);
disp("Sorted Array in Increasing Order:");
disp(sortedArray);
//////////////////////////////////////////////////////////////////////////////////////////////


--> function mergedArray = mergeSort(left,right)
  >     mergedArray =[];
  >     while length(left)>0 && length (right)>0
  > 
  >         if left(1)<right(1)
  >             mergedArray=[mergedArray,left(1)];
  >             left=left(2:$);
  >         else
  >             mergedArray=[mergedArray,right(1)];
  >             right=right(2:$);
  >         end
  >     end
  >     mergedArray=[mergedArray,left,right];
  > endfunction

--> function sortedArray = mergedArray(arr)
  >     if length(arr) <= 1 
  >         sortedArray =arr;
  >     else
  >         middle = floor(length(arr)/2);
  >         left = arr(1:middle);
  >         right =arr(middle+1 : $);
  > 
  >         sortedArray = mergeSort(mergedArray(left),mergedArray(right));
  >     end
  > endfunction

--> arr= [5,2,1,4,3];

--> sortedArray= mergedArray(arr);

--> disp("Sorted Array in Increasing Order:");

  "Sorted Array in Increasing Order:"

--> disp(sortedArray);

   1.   2.   3.   4.   5.


***********************************************************************************************
***********************************************************************************************
2. Write a Scilab program to solve the following problem:
Nuts & Bolts Problem (Lock & Key problem) using Quick Sort. Given a set of n nuts
of different sizes and n bolts of different sizes. There is a one-one mapping between
nuts and bolts. Match nuts and bolts efficiently.

Constraint: Comparison of a nut to another nut or a bolt to another bolt is not
allowed. It means a nut can only be compared with a bolt and a bolt can only be
compared with a nut to see which one is bigger/smaller. Another way of asking this
problem is, to give a box with locks and keys where one lock can be opened by one
key in the box. We need to match
the pair.


function [smaller, equal, larger] = partition(arr, pivot)
    smaller = [];
    equal = [];
    larger = [];

    for i = 1:length(arr) do
        if arr(i) < pivot then
            smaller = [smaller, arr(i)];
        elseif arr(i) == pivot then
            equal = [equal, arr(i)];
        else
            larger = [larger, arr(i)];
        end
    end
endfunction

function quickSortNutsBolts(nuts, bolts)
    n = length(nuts);

    if n <= 1 then
        return;
    end

    pivotBolt = bolts(1);

    [smallerNuts, equalNuts, largerNuts] = partition(nuts, pivotBolt);

    matchingNut = equalNuts(1);

    [smallerBolts, equalBolts, largerBolts] = partition(bolts, matchingNut);

    disp("Matching pair:");
    disp(matchingNut);
    disp(equalBolts(1));

    quickSortNutsBolts(smallerNuts, smallerBolts);
    quickSortNutsBolts(largerNuts, largerBolts);
endfunction

nuts = [5, 23, 32, 34, 7]; 
bolts = [7, 34, 23, 5, 32]; 

disp("Original Nuts:");
disp(nuts);

disp("Original Bolts:");
disp(bolts);

quickSortNutsBolts(nuts, bolts);



//////////////////////////////////////////////////////////////////////////////////////////////



--> function [smaller, equal, larger] = partition(arr, pivot)
  >     smaller = [];
  >     equal = [];
  >     larger = [];
  > 
  >     for i = 1:length(arr) do
  >         if arr(i) < pivot then
  >             smaller = [smaller, arr(i)];
  >         elseif arr(i) == pivot then
  >             equal = [equal, arr(i)];
  >         else
  >             larger = [larger, arr(i)];
  >         end
  >     end
  > endfunction

--> 

--> function quickSortNutsBolts(nuts, bolts)
  >     n = length(nuts);
  > 
  >     if n <= 1 then
  >         return;
  >     end
  > 
  >     pivotBolt = bolts(1);
  > 
  >     [smallerNuts, equalNuts, largerNuts] = partition(nuts, pivotBolt);
  > 
  >     matchingNut = equalNuts(1);
  > 
  >     [smallerBolts, equalBolts, largerBolts] = partition(bolts, matchingNut);
  > 
  >     disp("Matching pair:");
  >     disp(matchingNut);
  >     disp(equalBolts(1));
  > 
  >     quickSortNutsBolts(smallerNuts, smallerBolts);
  >     quickSortNutsBolts(largerNuts, largerBolts);
  > endfunction

--> 

--> nuts = [5, 23, 32, 34, 7]; 

--> bolts = [7, 34, 23, 5, 32]; 

--> 

--> disp("Original Nuts:");

  "Original Nuts:"

--> disp(nuts);

   5.   23.   32.   34.   7.

--> 

--> disp("Original Bolts:");

  "Original Bolts:"

--> disp(bolts);

   7.   34.   23.   5.   32.

--> 

--> quickSortNutsBolts(nuts, bolts);

  "Matching pair:"

   7.

   7.

  "Matching pair:"

   34.

   34.

  "Matching pair:"

   23.

   23.

***********************************************************************************************
***********************************************************************************************

