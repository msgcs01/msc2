//q1
/*
1. Given a set of cities and distance between every pair of cities, the problem is to find the shortest possible tour that visits every city exactly once and returns
to the starting point.
*/

function [min_distance, best_path] = tspBranchBound(cost_matrix)
    n = size(cost_matrix, 1);  // Number of cities

    visited = zeros(1, n); 
    visited(1) = 1; // Start from the first city (city 0)

    best_path = [];

    [min_distance, best_path] = tsp_recursive(cost_matrix, visited, 1, 0, 1, n, [0]);
endfunction

function [distance, best_path] = tsp_recursive(cost_matrix, visited, current_city, current_distance, count, n, current_path)

    if count == n then
        final_distance = current_distance + cost_matrix(current_city, 1); 
        current_path = [current_path, 0]; 
        distance = final_distance;
        best_path = current_path; // Store the best path found
        return;
    end
    
    min_distance = %inf; 
    best_path = [];    
    
 
    for next_city = 2:n
        if visited(next_city) == 0 then
            visited(next_city) = 1; // Mark the city as visited

            new_distance = current_distance + cost_matrix(current_city, next_city);
            
            [temp_distance, temp_path] = tsp_recursive(cost_matrix, visited, next_city, new_distance, count + 1, n, [current_path, next_city - 1]);
            
            
            if temp_distance < min_distance then
                min_distance = temp_distance;
                best_path = temp_path; // Update best path if a new minimum distance is found
            end
            
            visited(next_city) = 0; // Backtrack, mark the city as unvisited
        end
    end
    
    distance = min_distance; // Return the minimum distance for the current recursion level
endfunction


function path_str = join_path_with_arrow(path)
    path_str = string(path(1));  // Start with the first city
    for i = 2:length(path)
        path_str = path_str + "->" + string(path(i));  // Append each city with "->"
    end
endfunction


cost_matrix = [0 10 15 20; 10 0 35 25; 15 35 0 30; 20 25 30 0]; // Updated Distance matrix for 4 cities
[min_distance, best_path] = tspBranchBound(cost_matrix);

formatted_path = join_path_with_arrow(best_path);

// Display the results
disp("Shortest distance covering all cities is: " + string(min_distance));
disp("Best path for the tour is: " + formatted_path);




/*
2. Generate a binary string of length N using branch and bound technique.
(Input: N = 3 Output: 000 001 010 011 100 101 110 111 Explanation: Numbers with 3
binary digits are 0, 1, 2, 3, 4, 5, 6, 7 Input: N = 2 Output: 00 01 10 11)
*/

// Function to generate binary strings of length N
function generateBinaryStrings(N)
    // Initialize an empty string for the current combination
    current_string = '';
    // Call the recursive function to generate binary strings
    generateBinaryRecursive(N, current_string);
endfunction

// Recursive function to build binary strings
function generateBinaryRecursive(N, current_string)
    // Base case: if the current string length is N, display it
    if length(current_string) == N then
        disp(current_string);
        return;
    end

    // Recur for adding '0'
    generateBinaryRecursive(N, current_string + '0');

    // Recur for adding '1'
    generateBinaryRecursive(N, current_string + '1');
endfunction

// Test the function with N = 3 and N = 2
N1 = 3;
disp("Binary strings of length " + string(N1) + ":");
generateBinaryStrings(N1);

N2 = 2;
disp("Binary strings of length " + string(N2) + ":");
generateBinaryStrings(N2);
